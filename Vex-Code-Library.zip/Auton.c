#include "library.c"

void Auton() {
  /*
  * Place your Created Autonomous Here.
  * You Have Access to the Functions Given Above.
  */
  {
    // moveRight(100, 2);
    // moveForward(100, 3);
    // moveLeft(50, 4);
  }
}
